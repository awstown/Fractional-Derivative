% Fractional Derivatives - Subdiffusion - Diffusion Wave
%
% This package contains three scripts. Two that solve the subdiffusion equation
% and one that solves the diffusion-wave equation. When you open the folder you 
% will find another readme which instruct you on how to run the script. 
%

Thanks to John and Wade for making this an awesome summer.